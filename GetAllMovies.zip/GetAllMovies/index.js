const axios = require('axios');

exports.handler = async(event, context)=>{
    try{
        const{body,headers,httpMethod,path,queryStringParameters}=event;
        /*const config={
            method:httpMethod,
            url:''+path,
            headers:{
                ...headers
            },
            params:queryStringParameters,
            data:body,
        };*/

        const config={
            method:'GET',
            url:''+'health-check',
            headers:{'Content-type':'application/json'},
            
            
        };

        

        const response=await axios(config);
        return{
            statusCode:response.status,
            headers:response.headers,
            body:response.data
        };
    }catch(error){
        return{
            statusCode:error.response?error.response.status:500,
            body:error.message,
        };
    }
};